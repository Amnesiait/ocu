#!/bin/bash
sudo java -cp ../bin recipes_service.test.TestServer $*
